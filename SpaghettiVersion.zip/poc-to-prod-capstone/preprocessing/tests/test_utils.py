import unittest
import pandas as pd
from unittest.mock import MagicMock

from preprocessing.preprocessing import utils


class TestBaseTextCategorizationDataset(unittest.TestCase):
    def test__get_num_train_samples(self):
        base = utils.BaseTextCategorizationDataset(20, 0.8)
        base._get_num_samples = MagicMock(return_value=100)
        self.assertEqual(base._get_num_train_samples(), 80)
        #self.assertIsNone(base._get_num_train_samples())

    def test__get_num_train_batches(self):
        base = utils.BaseTextCategorizationDataset(20, 0.8)
        base._get_num_train_samples = MagicMock(return_value=80)
        base.batch_size = 20
        self.assertEqual(base._get_num_train_batches(), 4)  # 80 / 20 = 4 batches
        #self.assertIsNone(base._get_num_train_batches())

    def test__get_num_test_batches(self):
        base = utils.BaseTextCategorizationDataset(20, 0.8)
        base._get_num_test_samples = MagicMock(return_value=20)
        base.batch_size = 20
        self.assertEqual(base._get_num_test_batches(), 1)  # 20 / 20 = 1 batch
        #self.assertIsNone(base._get_num_test_batches())

    def test_get_index_to_label_map(self):
        class TestDataset(utils.BaseTextCategorizationDataset):
            _label_list = ['classA', 'classB']

        dataset = TestDataset(20, 0.8)
        expected_map = {0: 'classA', 1: 'classB'}
        self.assertDictEqual(dataset.get_index_to_label_map(), expected_map)

    def test_index_to_label_and_label_to_index_are_identity(self):
        class TestDataset(utils.BaseTextCategorizationDataset):
            _label_list = ['classA', 'classB']

        dataset = TestDataset(20, 0.8)
        index_to_label_map = dataset.get_index_to_label_map()
        label_to_index_map = dataset.get_label_to_index_map()
        self.assertDictEqual(index_to_label_map, {v: k for k, v in label_to_index_map.items()})

    def test_to_indexes(self):
        class TestDataset(utils.BaseTextCategorizationDataset):
            _label_list = ['classA', 'classB']

        dataset = TestDataset(20, 0.8)
        labels = ['classA', 'classB', 'classA']
        self.assertEqual(dataset.to_indexes(labels), [0, 1, 0])


class TestLocalTextCategorizationDataset(unittest.TestCase):
    def test_load_dataset_returns_expected_data(self):
        pd.read_csv = MagicMock(return_value=pd.DataFrame({
            'post_id': ['id_1', 'id_2'],
            'tag_name': ['tag_a', 'tag_b'],
            'tag_id': [1, 2],
            'tag_position': [0, 1],
            'title': ['title_1', 'title_2']
        }))
        dataset = utils.LocalTextCategorizationDataset.load_dataset("fake", 1)
        expected = pd.DataFrame({
            'post_id': ['id_1'],
            'tag_name': ['tag_a'],
            'tag_id': [1],
            'tag_position': [0],
            'title': ['title_1']
        })
        pd.testing.assert_frame_equal(dataset, expected)

    def test__get_num_samples_is_correct(self):
        dataset = utils.LocalTextCategorizationDataset("train/data/training-data/stackoverflow_posts.csv", 1)
        dataset._dataset = pd.DataFrame({
            'post_id': ['id_1', 'id_2', 'id_3'],
            'tag_name': ['tag_a', 'tag_b', 'tag_a'],
            'tag_id': [1, 2, 1],
            'tag_position': [0, 1, 0],
            'title': ['title_1', 'title_2', 'title_3']
        })
        self.assertEqual(dataset._get_num_samples(), 3)

    def test_get_train_batch_returns_expected_shape(self):
        dataset = utils.LocalTextCategorizationDataset("fake_path", 1)
        dataset.x_train = pd.Series(['title_1', 'title_2', 'title_3'])
        dataset.y_train = pd.get_dummies(pd.Series(['classA', 'classB', 'classA']))
        dataset.batch_size = 2
        batch_x, batch_y = dataset.get_train_batch()
        self.assertEqual(batch_x.shape, (2,))
        self.assertEqual(batch_y.shape, (2, 2))

    def test_get_test_batch_returns_expected_shape(self):
        dataset = utils.LocalTextCategorizationDataset("fake_path", 1)
        dataset.x_test = pd.Series(['title_1', 'title_2', 'title_3'])
        dataset.y_test = pd.get_dummies(pd.Series(['classA', 'classB', 'classA']))
        dataset.batch_size = 2
        batch_x, batch_y = dataset.get_test_batch()
        self.assertEqual(batch_x.shape, (2,))
        self.assertEqual(batch_y.shape, (2, 2))

    def test_get_train_batch_raises_assertion_error(self):
        dataset = utils.LocalTextCategorizationDataset("fake_path", 1)
        dataset.x_train = pd.Series(['title_1', 'title_2'])
        dataset.y_train = pd.get_dummies(pd.Series(['classA', 'classB']))
        dataset.batch_size = 3
        with self.assertRaises(AssertionError):
            dataset.get_train_batch()


if __name__ == '__main__':
    unittest.main()
