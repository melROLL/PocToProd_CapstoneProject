import unittest
from unittest.mock import MagicMock
import tempfile

import pandas as pd

from preprocessing.preprocessing import utils
from train.train.run import train


def load_dataset_mock():
    titles = [
        "Is it possible to execute the procedure of a function in the scope of the caller?",
        "ruby on rails: how to change BG color of options in select list, ruby-on-rails",
        "Is it possible to execute the procedure of a function in the scope of the caller?",
        "ruby on rails: how to change BG color of options in select list, ruby-on-rails",
        "Is it possible to execute the procedure of a function in the scope of the caller?",
        "ruby on rails: how to change BG color of options in select list, ruby-on-rails",
        "Is it possible to execute the procedure of a function in the scope of the caller?",
        "ruby on rails: how to change BG color of options in select list, ruby-on-rails",
        "Is it possible to execute the procedure of a function in the scope of the caller?",
        "ruby on rails: how to change BG color of options in select list, ruby-on-rails",
    ]
    tags = ["php", "ruby-on-rails", "php", "ruby-on-rails", "php", "ruby-on-rails", "php", "ruby-on-rails",
            "php", "ruby-on-rails"]

    return pd.DataFrame({
        'title': titles,
        'tag_name': tags
    })


class TestTrain(unittest.TestCase):
    utils.LocalTextCategorizationDataset.load_dataset = MagicMock(side_effect=load_dataset_mock())

    def test_train(self):
        params = {
            'batch_size': 2,
            'epochs': 1,
            'dense_dim': 8,
            'min_samples_per_label': 2,
            'verbose': 1
        }

        with tempfile.TemporaryDirectory() as model_dir:

            accuracy, _ = train("train/data/training-data/stackoverflow_posts.csv", params, model_dir, True)

        self.assertEqual(accuracy, 1.0)


if __name__ == '__main__':
    unittest.main()
